import base64
import ctypes
import hashlib
import io
import json
import math
import os
import re
import sys
import zipfile
from collections import Counter
from ctypes import wintypes

import pefile

BASE_DIR = os.path.dirname(
    os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__)
)
SIG_DB = os.path.join(BASE_DIR, "signatures.json")

PE_EXTS = (".exe", ".dll", ".sys", ".scr", ".cpl", ".ocx", ".com", ".pif")
SCRIPT_EXTS = (".ps1", ".bat", ".cmd", ".vbs", ".js", ".jse", ".vbe", ".hta", ".wsf")
EICAR_PREFIX = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"

EXCL_DIRS = ("\\_quarantine\\", "\\__pycache__\\", "\\.git\\")
EXCL_PREF = ("c:\\windows\\winsxs\\", "c:\\$winreagent\\")

APIS = {
    b"RtlDecompressBuffer": (20, "Распаковка скрытого кода в памяти"),
    b"CryptUnprotectData": (40, "Чтение зашифрованных паролей/куки (DPAPI)"),
    b"URLDownloadToFileW": (35, "Прямая загрузка файла из сети"),
    b"URLDownloadToFileA": (35, "Прямая загрузка файла из сети"),
    b"InternetOpenUrlW": (20, "Сетевое обращение к внешнему URL"),
    b"WinHttpOpen": (15, "Использование сетевого стека WinHTTP"),
    b"VirtualAllocEx": (25, "Выделение памяти в чужом процессе"),
    b"VirtualProtectEx": (25, "Изменение прав памяти в чужом процессе"),
    b"WriteProcessMemory": (35, "Запись кода в память чужой программы"),
    b"CreateRemoteThread": (35, "Запуск потока в чужом процессе"),
    b"NtUnmapViewOfSection": (45, "Подмена кода процесса (Process Hollowing)"),
    b"SetThreadContext": (30, "Перехват управления потоком (Injection)"),
    b"SetWindowsHookExW": (30, "Перехват нажатий клавиш (Кейлоггер)"),
    b"GetAsyncKeyState": (25, "Скрытое чтение клавиатуры (Кейлоггер)"),
    b"AdjustTokenPrivileges": (20, "Запрос системных привилегий отладки"),
    b"MiniDumpWriteDump": (45, "Дамп памяти процессов / кража учетных данных LSASS"),
    b"IsDebuggerPresent": (10, "Проверка на запуск в отладчике (Anti-Debug)"),
}

API_COMBOS = [
    (
        {b"VirtualAllocEx", b"WriteProcessMemory", b"CreateRemoteThread"},
        55,
        "ПОВЕДЕНИЕ: Внедрение исполняемого кода в чужой процесс (Injection)",
    ),
    (
        {b"NtUnmapViewOfSection", b"WriteProcessMemory", b"SetThreadContext"},
        65,
        "ПОВЕДЕНИЕ: Подмена легитимного процесса (Process Hollowing)",
    ),
    (
        {b"CryptUnprotectData", b"InternetOpenUrlW"},
        50,
        "ПОВЕДЕНИЕ: Кража данных браузера и отправка в сеть (Стиллер)",
    ),
    (
        {b"CryptUnprotectData", b"WinHttpOpen"},
        50,
        "ПОВЕДЕНИЕ: Кража данных DPAPI и сетевая передача (Стиллер)",
    ),
    (
        {b"SetWindowsHookExW", b"GetAsyncKeyState"},
        40,
        "ПОВЕДЕНИЕ: Перехват ввода пользователя (Кейлоггер)",
    ),
    (
        {b"AdjustTokenPrivileges", b"MiniDumpWriteDump"},
        65,
        "ПОВЕДЕНИЕ: Попытка дампа системных паролей из памяти (Credential Dumping)",
    ),
]

SCRIPT_ACTIONS = [
    (r"(invoke-webrequest|iwr|wget|curl|downloadstring|downloadfile)\s*[\(\s'\"]*https?://", 50, "Скрипт скачивает нагрузку из интернета"),
    (r"(iex|invoke-expression)\s*[\(\s\$]", 45, "Динамическое выполнение кода в памяти (IEX)"),
    (r"\[convert\]::frombase64string", 45, "Декодирование скрытой Base64-нагрузки в PowerShell"),
    (r"powershell.*(-enc|-encodedcommand)\s+[a-z0-9+/=]{20,}", 55, "Скрытый запуск зашифрованной команды PowerShell"),
    (r"powershell.*(-w\s+hidden|-windowstyle\s+hidden)", 35, "Скрытие окна консоли от пользователя"),
    (r"certutil.*-urlcache.*-f\s+https?://", 55, "Использование системной утилиты certutil для загрузки из сети"),
    (r"bitsadmin.*/transfer.*https?://", 55, "Скрытая загрузка файла через bitsadmin"),
    (r"mshta\s+https?://", 60, "Запуск удаленного вредоносного HTA-сценария"),
    (r"(add-mppreference|set-mppreference).*(-exclusionpath|-disablerealtimemonitoring)", 65, "Попытка отключить или обойти Защитник Windows"),
    (r"vssadmin\s+delete\s+shadows", 80, "Уничтожение теневых копий дисков (Действие шифровальщика)"),
    (r"bcdedit.*recoveryenabled\s+no", 75, "Блокировка среды восстановления Windows"),
    (r"wevtutil\s+(cl|clear-log)", 55, "Очистка системных журналов событий Windows (Сокрытие следов)"),
]

PACKER_SECTIONS = (b"upx", b".vmp", b".enigma", b".aspack", b".petite", b".themida", b".nsp")
_DB, _MT = None, 0.0


def load_db():
    global _DB, _MT
    try:
        mt = os.path.getmtime(SIG_DB)
        if _DB is not None and mt == _MT:
            return _DB
        with open(SIG_DB, "r", encoding="utf-8") as f:
            _DB, _MT = json.load(f), mt
            return _DB
    except Exception:
        return {"malware_hashes_sha256": {}, "dangerous_strings": [], "whitelist_paths": []}


def add_to_whitelist(p: str):
    db, norm = load_db(), os.path.abspath(p).lower()
    if norm not in db.get("whitelist_paths", []):
        db.setdefault("whitelist_paths", []).append(norm)
        with open(SIG_DB, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=2)


def is_whitelisted(p: str) -> bool:
    return os.path.abspath(p).lower() in load_db().get("whitelist_paths", [])


def is_excluded(p: str, strict: bool = False) -> bool:
    if strict:
        return False
    low, base = os.path.abspath(p).lower(), BASE_DIR.lower()
    return (
        low == base
        or low.startswith(base + os.sep)
        or low.startswith(EXCL_PREF)
        or any(x in low for x in EXCL_DIRS)
    )


class WT_INFO(ctypes.Structure):
    _fields_ = [
        ("cbStruct", wintypes.DWORD),
        ("pcwszFilePath", wintypes.LPCWSTR),
        ("hFile", wintypes.HANDLE),
        ("pgKnownSubject", ctypes.c_void_p),
    ]


class WT_DATA(ctypes.Structure):
    _fields_ = [
        ("cbStruct", wintypes.DWORD),
        ("pPolicyCallbackData", ctypes.c_void_p),
        ("pSIPClientData", ctypes.c_void_p),
        ("dwUIChoice", wintypes.DWORD),
        ("fdwRevocationChecks", wintypes.DWORD),
        ("dwUnionChoice", wintypes.DWORD),
        ("pFile", ctypes.POINTER(WT_INFO)),
        ("dwStateAction", wintypes.DWORD),
        ("hWVTStateData", wintypes.HANDLE),
        ("pwszURLReference", wintypes.LPCWSTR),
        ("dwProvFlags", wintypes.DWORD),
        ("dwUIContext", wintypes.DWORD),
    ]


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]


if os.name == "nt":
    _wintrust = ctypes.windll.wintrust

    _wintrust.WinVerifyTrust.argtypes = [wintypes.HWND, ctypes.POINTER(GUID), ctypes.POINTER(WT_DATA)]
    _wintrust.WinVerifyTrust.restype = wintypes.LONG

    _wintrust.CryptCATAdminAcquireContext.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(GUID), wintypes.DWORD]
    _wintrust.CryptCATAdminAcquireContext.restype = wintypes.BOOL

    _wintrust.CryptCATAdminEnumCatalogFromHash.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_ubyte),
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.POINTER(ctypes.c_void_p),
    ]
    _wintrust.CryptCATAdminEnumCatalogFromHash.restype = ctypes.c_void_p

    _wintrust.CryptCATAdminReleaseCatalogContext.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD]
    _wintrust.CryptCATAdminReleaseCatalogContext.restype = wintypes.BOOL

    _wintrust.CryptCATAdminReleaseContext.argtypes = [ctypes.c_void_p, wintypes.DWORD]
    _wintrust.CryptCATAdminReleaseContext.restype = wintypes.BOOL


def _sha1_file_stream(p: str) -> bytes:
    h = hashlib.sha1()
    with open(p, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.digest()


def verify_windows_signature(p: str) -> bool:
    """Проверяет как встроенную подпись файла, так и системный каталог безопасности Windows (CatRoot)."""
    if os.name != "nt":
        return False
    try:
        fi = WT_INFO(cbStruct=ctypes.sizeof(WT_INFO), pcwszFilePath=p)
        td = WT_DATA(
            cbStruct=ctypes.sizeof(WT_DATA),
            dwUIChoice=2,
            dwUnionChoice=1,
            pFile=ctypes.pointer(fi),
            dwStateAction=1,
        )
        g = GUID(
            0x00AAC56B, 0xCD44, 0x11D0,
            (ctypes.c_ubyte * 8)(0x8C, 0xC2, 0x00, 0xC0, 0x4F, 0xC2, 0x95, 0xEE),
        )
        res = _wintrust.WinVerifyTrust(None, ctypes.byref(g), ctypes.byref(td))
        td.dwStateAction = 2
        _wintrust.WinVerifyTrust(None, ctypes.byref(g), ctypes.byref(td))
        if res == 0:
            return True

        h_cat = ctypes.c_void_p()
        if _wintrust.CryptCATAdminAcquireContext(ctypes.byref(h_cat), None, 0):
            try:
                sha1_digest = _sha1_file_stream(p)
                hash_buf = (ctypes.c_ubyte * len(sha1_digest))(*sha1_digest)
                h_info = _wintrust.CryptCATAdminEnumCatalogFromHash(
                    h_cat, hash_buf, len(sha1_digest), 0, None
                )
                if h_info:
                    _wintrust.CryptCATAdminReleaseCatalogContext(h_cat, h_info, 0)
                    return True
            finally:
                _wintrust.CryptCATAdminReleaseContext(h_cat, 0)
        return False
    except Exception:
        return False

def is_hidden_file(p: str) -> bool:
    if os.name != "nt":
        return os.path.basename(p).startswith(".")
    try:
        a = ctypes.windll.kernel32.GetFileAttributesW(p)
        return False if a == -1 else bool(a & 0x2)
    except Exception:
        return False


def is_eicar(data: bytes) -> bool:
    head = data.lstrip()[:128]
    return EICAR_PREFIX in head or b"EICAR-STANDARD-ANTIVIRUS-TEST-FILE" in head


def get_entropy(data: bytes) -> float:
    n = len(data)
    if not n:
        return 0.0
    counts = Counter(data)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def _check_xor_obfuscation(data: bytes, db: dict):
    """Перебор всех 255 однобайтовых XOR-ключей для поиска скрытых URL и команд."""
    sample = data[:1048576]
    targets = [
        it["pattern"].lower().encode()
        for it in db.get("dangerous_strings", [])
        if len(it["pattern"]) >= 7
    ]
    targets.extend([b"https://", b"http://", b"powershell", b"cmd.exe", b"virtualallocex"])

    for key in range(1, 256):
        xored = bytes(b ^ key for b in sample).lower()
        for t in targets:
            if t in xored:
                return 45, f"XOR-зашифрованная строка '{t.decode(errors='ignore')}' (ключ 0x{key:02X}) (+45)"
    return 0, None


def _search_strings_multibyte(data_lower: bytes, db: dict):
    score, reasons = 0, []
    for it in db.get("dangerous_strings", []):
        pat_str = it["pattern"].lower()
        if (
            pat_str.encode("utf-8", errors="ignore") in data_lower
            or pat_str.encode("utf-16le", errors="ignore") in data_lower
        ):
            score += it["score"]
            reasons.append(f"{it['desc']} (+{it['score']})")
    return score, reasons


def _is_executable_pe(data: bytes) -> bool:
    """Проверяет, является ли MZ-файл настоящей исполняемой программой."""
    pe = None
    try:
        pe = pefile.PE(data=data, fast_load=True)
        has_ep = pe.OPTIONAL_HEADER.AddressOfEntryPoint > 0
        has_sections = len(pe.sections) > 0
        pe.parse_data_directories(
            directories=[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_IMPORT"]]
        )
        has_imports = hasattr(pe, "DIRECTORY_ENTRY_IMPORT") and len(pe.DIRECTORY_ENTRY_IMPORT) > 0
        return has_ep and has_sections and has_imports
    except Exception:
        return False
    finally:
        if pe:
            pe.close()


def _check_ntfs_ads(p: str):
    """Проверяет скрытые альтернативные потоки данных (ADS) в NTFS."""
    if os.name != "nt":
        return 0, None
    common_streams = (":payload", ":hidden", ":data", ":exe", ":bin", ":run", ":vbs", ":ps1", ":bat")
    for st in common_streams:
        ads_path = p + st
        try:
            if os.path.exists(ads_path):
                with open(ads_path, "rb") as f:
                    head = f.read(64)
                if head.startswith(b"MZ") or b"powershell" in head.lower():
                    return 90, f"Обнаружен скрытый исполняемый поток NTFS '{st}' (+90)"
        except Exception:
            pass
    return 0, None


def _read_pe_safe(p: str, sz: int) -> tuple[bytes, bool]:
    """Читает файл с защитой от File Pumping (искусственного раздувания нулями)."""
    max_full = 67108864  # 64 МБ
    if sz <= max_full:
        with open(p, "rb") as f:
            return f.read(), False
    with open(p, "rb") as f:
        head = f.read(16777216)  # Первые 16 МБ (заголовки + секции кода/данных)
        f.seek(max(0, sz - 2097152))
        tail = f.read(2097152)   # Последние 2 МБ (оверлей)
    is_pumped = tail.count(b"\x00") > 1800000
    return head + tail, is_pumped


def scan_pe(data: bytes, trusted: bool, is_pumped: bool = False):
    if is_eicar(data):
        return 100, ["Сигнатура EICAR! (+100)"]
    db = load_db()
    h = hashlib.sha256(data).hexdigest().lower()
    if h in db.get("malware_hashes_sha256", {}):
        return 100, [f"База SHA-256: {db['malware_hashes_sha256'][h]} (+100)"]

    if trusted:
        return 0, ["Подтвержденная цифровая подпись / каталог Windows"]

    score, reasons = 15, ["Нет проверенной цифровой подписи (+15)"]
    if is_pumped:
        score += 35
        reasons.append("Искусственное раздувание файла нулями (File Pumping) (+35)")

    pe = None
    try:
        pe = pefile.PE(data=data, fast_load=True)
        pe.parse_data_directories(
            directories=[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_IMPORT"]]
        )

        ep = pe.OPTIONAL_HEADER.AddressOfEntryPoint
        if ep == 0 and not hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
            return 0, ["Ресурсный контейнер без исполняемого кода"]

        ts = pe.FILE_HEADER.TimeDateStamp
        if ts == 0 or ts > 1893456000:
            score += 15
            reasons.append("Поддельная метка времени компиляции PE (+15)")

        ep_in_code = rwx_found = high_entropy_found = False
        for s in pe.sections:
            sec_name = s.Name.rstrip(b"\x00").lower()
            ent, chars = s.get_entropy(), s.Characteristics

            if (chars & 0x20000000) and (chars & 0x80000000) and not rwx_found:
                rwx_found = True
                score += 25
                reasons.append("Секция с правами RWX (самораспаковка в памяти) (+25)")

            if any(pk in sec_name for pk in PACKER_SECTIONS):
                score += 20
                reasons.append(f"Секция упаковщика '{sec_name.decode(errors='ignore')}' (+20)")

            if ent > 7.45 and not high_entropy_found:
                high_entropy_found = True
                score += 15
                reasons.append(f"Высокая энтропия секции ({ent:.2f}) — код зашифрован (+15)")

            if s.VirtualAddress <= ep < (s.VirtualAddress + s.Misc_VirtualSize):
                if sec_name in (b".text", b"code", b".code"):
                    ep_in_code = True

        if ep > 0 and not ep_in_code:
            score += 20
            reasons.append("Точка входа (Entry Point) вне стандартной секции кода (+20)")

        found_apis = set()
        if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
            for e in pe.DIRECTORY_ENTRY_IMPORT:
                for imp in e.imports:
                    if imp.name in APIS and imp.name not in found_apis:
                        found_apis.add(imp.name)
                        pts, desc = APIS[imp.name]
                        score += pts
                        reasons.append(f"{imp.name.decode()}: {desc} (+{pts})")

        # Поиск скрытых динамических вызовов WinAPI вне таблицы импортов (GetProcAddress)
        for api_name, (pts, desc) in APIS.items():
            if api_name not in found_apis and api_name in data:
                found_apis.add(api_name)
                add_pts = max(10, pts // 2)
                score += add_pts
                reasons.append(f"Скрытый вызов {api_name.decode()} вне таблицы импортов (+{add_pts})")

        for combo_set, c_pts, c_desc in API_COMBOS:
            if combo_set.issubset(found_apis):
                score += c_pts
                reasons.append(f"{c_desc} (+{c_pts})")

        s_pts, s_reasons = _search_strings_multibyte(data.lower(), db)
        score += s_pts
        reasons.extend(s_reasons)

        if score >= 30:
            xor_pts, xor_msg = _check_xor_obfuscation(data, db)
            if xor_pts:
                score += xor_pts
                reasons.append(xor_msg)

        ov = pe.get_overlay_data_start_offset()
        if ov and ov < len(data) and get_entropy(data[ov : ov + 2097152]) > 7.4:
            score += 25
            reasons.append("Скрытый зашифрованный блок в конце файла (+25)")

        return min(100, score), reasons
    except Exception:
        return 20, ["Нестандартный или поврежденный заголовок PE (+20)"]
    finally:
        if pe:
            pe.close()


def scan_script(data: bytes):
    if is_eicar(data):
        return 100, ["Сигнатура EICAR! (+100)"]
    db = load_db()
    score, reasons = 0, []
    raw_txt = data.decode(errors="ignore")
    decoded_extra = ""

    for m in re.findall(r"[a-zA-Z0-9+/=]{40,}", raw_txt)[:10]:
        try:
            raw = base64.b64decode(m)
            decoded_extra += (
                " "
                + raw.decode("utf-16le", errors="ignore").lower()
                + " "
                + raw.decode("utf-8", errors="ignore").lower()
            )
        except Exception:
            pass

    full_txt = raw_txt.lower() + decoded_extra
    # Деобфускация разрывов команд (^, `, " + ")
    clean_txt = re.sub(r"[\^`]", "", full_txt)
    clean_txt = re.sub(r"['\"]\s*\+\s*['\"]", "", clean_txt)

    for pattern, pts, desc in SCRIPT_ACTIONS:
        if re.search(pattern, clean_txt, re.IGNORECASE | re.DOTALL):
            score += pts
            reasons.append(f"{desc} (+{pts})")

    for it in db.get("dangerous_strings", []):
        if it["pattern"].lower() in clean_txt:
            score += it["score"]
            reasons.append(f"{it['desc']} (+{it['score']})")

    return min(100, score), reasons


def scan_lnk(data: bytes):
    score, reasons = 0, []
    txt = (
        data.decode("utf-16le", errors="ignore").lower()
        + " "
        + data.decode("latin1", errors="ignore").lower()
    )
    danger_cmds = [
        ("powershell", 45, "Ярлык вызывает PowerShell"),
        ("cmd.exe", 35, "Ярлык вызывает cmd.exe"),
        ("mshta", 55, "Ярлык запускает mshta.exe"),
        ("wscript", 45, "Ярлык запускает WScript"),
        ("cscript", 45, "Ярлык запускает CScript"),
        ("rundll32", 40, "Ярлык вызывает rundll32"),
        ("regsvr32", 45, "Ярлык вызывает regsvr32"),
        ("http://", 35, "В ярлык вшита HTTP-ссылка"),
        ("https://", 30, "В ярлык вшита HTTPS-ссылка"),
    ]
    for cmd, pts, desc in danger_cmds:
        if cmd in txt:
            score += pts
            reasons.append(f"{desc} (+{pts})")
    return min(100, score), reasons


def deep_reverify(cand: tuple):
    score, _, path, reasons = cand

def deep_reverify(cand: tuple):
    score, _, path, reasons = cand
    if is_whitelisted(path) or is_excluded(path) or verify_windows_signature(path):
        return None
    critical = (
        "EICAR",
        "Маскировка",
        "SHA-256",
        "Стиллер",
        "криптомайнер",
        "Защитника",
        "DPAPI",
        "шифровальщика",
        "ПОВЕДЕНИЕ:",
        "XOR-зашифрованная",
        "Двойное расширение",
        "поток NTFS",
        "File Pumping",
    )
    if any(k in r for r in reasons for k in critical):
        return (
            max(85, score),
            "ВЫСОКАЯ ОПАСНОСТЬ",
            path,
            reasons + ["[Перепроверено] Поведенческий вердикт подтвержден"],
        )
    if score < 80:
        return None
    return (
        score,
        "ВЫСОКАЯ ОПАСНОСТЬ",
        path,
        reasons + ["[Перепроверено] Высокий индекс риска"],
    )


def _scan_zip_bytes(zip_bytes: bytes, container_name: str, depth: int = 0):
    """Рекурсивная проверка ZIP-архивов с приоритетом опасных форматов и защитой от ZIP-бомб."""
    best_score, best_reasons = 0, []
    if depth > 2:
        return 0, []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            priority_exts = PE_EXTS + SCRIPT_EXTS + (".lnk", ".zip")
            entries = sorted(
                [i for i in zf.infolist() if not i.is_dir()],
                key=lambda x: 0 if os.path.splitext(x.filename)[1].lower() in priority_exts else 1,
            )
            for i in entries[:250]:
                ie = os.path.splitext(i.filename)[1].lower()
                with zf.open(i) as zf_item:
                    inn = zf_item.read(33554432)  # Безопасный лимит чтения 32 МБ
                if not inn:
                    continue
                if is_eicar(inn):
                    return 100, [f"EICAR в {container_name} -> {i.filename} (+100)"]
                if ie in PE_EXTS or inn.startswith(b"MZ"):
                    s, r = scan_pe(inn, False)
                    if s > best_score:
                        best_score, best_reasons = s, [f"В архиве ({i.filename}):"] + r
                elif ie in SCRIPT_EXTS:
                    s, r = scan_script(inn)
                    if s > best_score:
                        best_score, best_reasons = s, [f"В архиве ({i.filename}):"] + r
                elif ie == ".lnk":
                    s, r = scan_lnk(inn)
                    if s > best_score:
                        best_score, best_reasons = s, [f"Ярлык в архиве ({i.filename}):"] + r
                elif ie == ".zip":
                    s, r = _scan_zip_bytes(inn, i.filename, depth + 1)
                    if s > best_score:
                        best_score, best_reasons = s, r
                if best_score >= 95:
                    break
    except Exception:
        pass
    return best_score, best_reasons


def analyze_file_worker(p: str, strict_mode: bool = False):
    try:
        if is_whitelisted(p):
            return (0, "БЕЗОПАСНО", p, ["В Белом списке"]) if strict_mode else None
        if is_excluded(p, strict_mode) or os.path.islink(p):
            return None
        sz = os.path.getsize(p)
        ext = os.path.splitext(p)[1].lower()

        # Не пропускаем большие PE-файлы (защита от File Pumping), ограничиваем только прочие
        if not strict_mode and ext not in PE_EXTS and sz > 157286400:
            return None

        fname_low = os.path.basename(p).lower()
        hid = is_hidden_file(p)
        low = p.lower()
        score, reasons = 0, []

        ads_pts, ads_msg = _check_ntfs_ads(p)
        if ads_pts:
            score += ads_pts
            reasons.append(ads_msg)

        fake_exts = (".pdf.", ".doc.", ".docx.", ".xls.", ".xlsx.", ".jpg.", ".png.", ".txt.", ".mp4.")
        if ext in PE_EXTS + SCRIPT_EXTS + (".lnk",) and any(fe in fname_low for fe in fake_exts):
            score += 55
            reasons.append("Двойное расширение файла — маскировка под документ (+55)")

        if ext in PE_EXTS:
            if sz == 0:
                return (0, "БЕЗОПАСНО", p, ["Пустой файл"]) if strict_mode else None
            tr = verify_windows_signature(p)
            if tr and not strict_mode:
                return None
            pe_data, is_pumped = _read_pe_safe(p, sz)
            pe_score, pe_reasons = scan_pe(pe_data, tr, is_pumped)
            score = min(100, score + pe_score)
            reasons.extend(pe_reasons)

            if not tr and pe_score > 0 and any(
                k in low for k in ("\\appdata\\", "\\temp\\", "\\downloads\\", "\\programdata\\")
            ):
                score = min(100, score + 15)
                reasons.append("Неподписанный код в пользовательской зоне риска (+15)")
            if not tr and pe_score > 0 and hid:
                score = min(100, score + 25)
                reasons.append("Скрытый атрибут исполняемого файла (+25)")

        elif ext in SCRIPT_EXTS:
            with open(p, "rb") as f:
                sc_score, sc_reasons = scan_script(f.read(4194304))
            score = min(100, score + sc_score)
            reasons.extend(sc_reasons)
            if hid and score > 0:
                score = min(100, score + 20)
                reasons.append("Скрытый вредоносный скрипт (+20)")

        elif ext == ".lnk":
            if sz <= 65536:
                with open(p, "rb") as f:
                    lnk_score, lnk_reasons = scan_lnk(f.read())
                score = min(100, score + lnk_score)
                reasons.extend(lnk_reasons)

        elif ext == ".zip":
            if sz <= 104857600:
                with open(p, "rb") as f:
                    z_score, z_reasons = _scan_zip_bytes(f.read(), os.path.basename(p))
                score = min(100, score + z_score)
                reasons.extend(z_reasons)

        else:
            if sz == 0:
                return (0, "БЕЗОПАСНО", p, ["Пустой файл"]) if strict_mode else None
            with open(p, "rb") as f:
                head = f.read(128)
            if is_eicar(head):
                return (100, "ВЫСОКАЯ ОПАСНОСТЬ", p, ["Сигнатура EICAR! (+100)"])

            non_exec_res = (
                ".mui", ".pyd", ".ax", ".efi", ".drv",
                ".winmd", ".tlb", ".asi", ".bpl", ".ime", ".acm",
                ".node", ".tmp", ".msi", ".quarantined", ".rll", ".dub",
                ".hxs", ".lex",
            )
            if head.startswith(b"MZ") and ext not in non_exec_res and ext != "":
                if not verify_windows_signature(p):
                    pe_data, _ = _read_pe_safe(p, sz)
                    if _is_executable_pe(pe_data):
                        return (
                            100,
                            "ВЫСОКАЯ ОПАСНОСТЬ",
                            p,
                            [f"Маскировка исполняемой программы под '{ext}' (+100)"],
                        )

            if score == 0:
                return (0, "БЕЗОПАСНО", p, ["Угроз не обнаружено"]) if strict_mode else None

        status = (
            "ВЫСОКАЯ ОПАСНОСТЬ"
            if score >= 75
            else "ПОДОЗРИТЕЛЬНО"
            if score >= 45
            else "БЕЗОПАСНО"
        )
        if not strict_mode and status == "БЕЗОПАСНО":
            return None
        return (score, status, p, reasons or ["Угроз не обнаружено"])
    except Exception:
        return None
