import csv
import ctypes
import io
import os
import subprocess
import winreg
from engine import is_whitelisted, verify_windows_signature

CREATE_NO_WINDOW = 0x08000000
PROCESS_SUSPEND_RESUME = 0x0800


def _run_cmd(cmd, use_shell: bool = False) -> str:
    try:
        return subprocess.check_output(
            cmd,
            shell=use_shell,
            encoding="cp866",
            errors="ignore",
            creationflags=CREATE_NO_WINDOW,
        )
    except Exception:
        return ""


def _suspend_process(pid: int):
    """Мгновенно замораживает все потоки процесса через NtSuspendProcess, чтобы Watchdog не успел его перезапустить."""
    if os.name != "nt":
        return
    try:
        h_proc = ctypes.windll.kernel32.OpenProcess(PROCESS_SUSPEND_RESUME, False, pid)
        if h_proc:
            try:
                ctypes.windll.ntdll.NtSuspendProcess(h_proc)
            finally:
                ctypes.windll.kernel32.CloseHandle(h_proc)
    except Exception:
        pass


def _get_pid_names() -> dict:
    mapping = {}
    out = _run_cmd(["tasklist", "/FO", "CSV", "/NH"])
    for row in csv.reader(io.StringIO(out)):
        if len(row) >= 2:
            mapping[row[1].strip()] = row[0].strip()
    return mapping


def scan_running_processes():
    results = []
    ps_script = (
        "[Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding(866); "
        "Get-CimInstance Win32_Process | Select-Object ProcessId,Name,ExecutablePath,CommandLine | ConvertTo-Csv -NoTypeInformation"
    )
    cmd = ["powershell", "-NoProfile", "-Command", ps_script]
    out = _run_cmd(cmd)
    lines = out.splitlines()
    if len(lines) < 2:
        return results

    for row in csv.reader(io.StringIO("\n".join(lines[1:]))):
        if len(row) < 3:
            continue
        pid, name, path = row[0].strip(), row[1].strip(), row[2].strip()
        cmd_line = row[3].strip().lower() if len(row) > 3 else ""

        if not pid.isdigit() or not path or not os.path.exists(path) or is_whitelisted(path):
            continue

        low = path.lower()
        name_low = name.lower()
        score, reasons = 0, []

        sys_names = ("svchost.exe", "lsass.exe", "csrss.exe", "explorer.exe", "winlogon.exe", "services.exe")
        if name_low in sys_names and "\\windows\\" not in low:
            score += 90
            reasons.append(f"Поддельный системный процесс '{name}' вне Windows! (+90)")

        if name_low in ("powershell.exe", "cmd.exe", "mshta.exe", "rundll32.exe", "wscript.exe", "cscript.exe"):
            if any(k in cmd_line for k in ("-enc", "-encodedcommand", "downloadstring", "frombase64string", "http://", "https://", "iex")):
                score += 85
                reasons.append("Системный интерпретатор запущен со скрытой сетевой/зашифрованной нагрузкой (+85)")

        # Пользовательские каталоги с легитимными установщиками (VS Code, Telegram и др.) проверяем только на подделку
        is_user_prog = "\\appdata\\local\\programs\\" in low or "\\microsoft\\windowsapps\\" in low
        if not is_user_prog and not verify_windows_signature(path):
            score += 25
            reasons.append("Нет цифровой подписи (+25)")
            if any(k in low for k in ("\\temp\\", "\\downloads\\", "\\programdata\\")):
                score += 55
                reasons.append("Запущен из опасной папки Temp/Downloads/ProgramData (+55)")

        if score >= 80:
            results.append((
                min(100, score),
                "ПРОЦЕСС В ПАМЯТИ",
                path,
                reasons + [f"PID: {pid} | Имя: {name}"],
                {"type": "process", "pid": pid, "path": path},
            ))
    return results


def _scan_scheduled_tasks():
    findings = []
    out = _run_cmd(["schtasks", "/Query", "/FO", "CSV", "/V", "/NH"])
    for row in csv.reader(io.StringIO(out)):
        if len(row) < 9:
            continue
        task_name = row[1].strip()
        action = row[8].strip()
        if not task_name.startswith("\\") or not action or action == "N/A":
            continue

        low = os.path.expandvars(action).lower()
        is_ms_branch = task_name.startswith("\\Microsoft\\")
        score, reasons = 0, []

        if any(k in low for k in ("powershell", "cmd.exe", "mshta", "wscript", "cscript", "rundll32", "regsvr32", "-enc")):
            score += 60
            reasons.append("Задача планировщика запускает скрытый интерпретатор (+60)")
        if any(k in low for k in ("\\appdata\\", "\\temp\\", "\\downloads\\", "\\programdata\\")):
            score += 35
            reasons.append("Запуск из временной/пользовательской папки (+35)")
            if is_ms_branch:
                score += 20
                reasons.append("Маскировка вредоносной задачи внутри ветки \\Microsoft\\ (+20)")

        if score >= 80:
            findings.append((
                min(100, score),
                "ПЛАНИРОВЩИК ЗАДАНИЙ",
                f"{task_name} -> {action}",
                reasons,
                {"type": "task", "task_name": task_name},
            ))
    return findings


def _scan_winlogon_and_ifeo():
    """Проверка подмены системной оболочки Winlogon и перехватчиков отладчика (IFEO)."""
    findings = []
    wl_subkey = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, wl_subkey) as key:
            for val_name, expected in (("Shell", "explorer.exe"), ("Userinit", "userinit.exe")):
                try:
                    v_data, _ = winreg.QueryValueEx(key, val_name)
                    val_low = str(v_data).strip().lower()
                    if expected not in val_low or "," in val_low.rstrip(","):
                        findings.append((
                            95,
                            "ПЕРЕХВАТ WINLOGON",
                            f"[HKLM\\Winlogon] {val_name} -> {v_data}",
                            [f"Изменен критический параметр загрузки Windows '{val_name}' (+95)"],
                            {"type": "autorun", "hive": winreg.HKEY_LOCAL_MACHINE, "subkey": wl_subkey, "name": val_name},
                        ))
                except FileNotFoundError:
                    pass
    except Exception:
        pass

    ifeo_base = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options"
    targets = ("sethc.exe", "utilman.exe", "osk.exe", "magnify.exe", "taskmgr.exe", "msconfig.exe")
    for exe_name in targets:
        sub = f"{ifeo_base}\\{exe_name}"
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, sub) as key:
                dbg, _ = winreg.QueryValueEx(key, "Debugger")
                if dbg:
                    findings.append((
                        95,
                        "ПОДМЕНА СИСТЕМНОЙ УТИЛИТЫ (IFEO)",
                        f"[IFEO\\{exe_name}] Debugger -> {dbg}",
                        ["Установлен перехват запуска системной программы (+95)"],
                        {"type": "autorun", "hive": winreg.HKEY_LOCAL_MACHINE, "subkey": sub, "name": "Debugger"},
                    ))
        except Exception:
            pass
    return findings


def _scan_hosts_file():
    findings = []
    hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
    danger_domains = (
        "kaspersky", "drweb", "malwarebytes", "virustotal", "avast", "eset",
        "sberbank", "tinkoff", "tbank", "vtb", "gosuslugi", "update.microsoft",
    )
    try:
        if os.path.exists(hosts_path):
            with open(hosts_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    clean = line.strip()
                    if not clean or clean.startswith("#"):
                        continue
                    code_part = clean.split("#", 1)[0].lower()
                    if any(d in code_part for d in danger_domains):
                        findings.append((
                            90,
                            "ПОДМЕНА ФАЙЛА HOSTS",
                            f"{hosts_path} -> {clean}",
                            ["Блокировка или перенаправление важного домена (+90)"],
                            {"type": "hosts", "line": clean},
                        ))
    except Exception:
        pass
    return findings


def scan_autorun():
    findings = []
    regs = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU\\Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM\\Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM\\WOW6432\\Run"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU\\RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM\\RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM\\WOW6432\\RunOnce"),
    ]
    for hive, subkey, label in regs:
        try:
            with winreg.OpenKey(hive, subkey) as key:
                i = 0
                while True:
                    try:
                        v_name, v_data, _ = winreg.EnumValue(key, i)
                        i += 1
                        expanded = os.path.expandvars(str(v_data)).lower()
                        score, reasons = 0, []
                        if any(k in expanded for k in ("powershell", "cmd.exe", "wscript", "mshta", "rundll32", "-enc")):
                            score += 65
                            reasons.append("Скрытый запуск через командный интерпретатор (+65)")
                        if any(k in expanded for k in ("\\temp\\", "\\downloads\\", "\\programdata\\", "\\appdata\\")):
                            score += 25
                            reasons.append("Автозапуск из пользовательской/временной папки (+25)")
                        if score >= 80:

                         if score >= 80:
                            findings.append((
                                min(100, score),
                                "ОБЪЕКТ АВТОЗАПУСКА",
                                f"[{label}] {v_name} -> {v_data}",
                                reasons,
                                {"type": "autorun", "hive": hive, "subkey": subkey, "name": v_name},
                            ))
                    except OSError:
                        break
        except Exception:
            pass

    # Проверка папок автозагрузки Startup (Пользователь и Все пользователи)
    startup_dirs = [
        os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup"),
        os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs\Startup"),
    ]
    for s_dir in startup_dirs:
        if os.path.isdir(s_dir):
            for fn in os.listdir(s_dir):
                if fn.lower() == "desktop.ini":
                    continue
                fp = os.path.join(s_dir, fn)
                if os.path.isfile(fp) and not is_whitelisted(fp) and not verify_windows_signature(fp):
                    ext = os.path.splitext(fn)[1].lower()
                    if ext in (".bat", ".cmd", ".ps1", ".vbs", ".js", ".hta", ".exe", ".scr", ".lnk"):
                        findings.append((
                            85,
                            "ПАПКА АВТОЗАГРУЗКИ STARTUP",
                            fp,
                            ["Неподписанный исполняемый файл/скрипт в папке Startup (+85)"],
                            {"type": "file", "path": fp},
                        ))

    findings.extend(_scan_winlogon_and_ifeo())
    findings.extend(_scan_scheduled_tasks())
    findings.extend(_scan_hosts_file())
    return findings


def remove_autorun_entry(hive, subkey, value_name) -> bool:
    try:
        with winreg.OpenKey(hive, subkey, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, value_name)
        return True
    except Exception:
        return False


def remove_scheduled_task(task_name: str) -> bool:
    try:
        subprocess.run(
            ["schtasks", "/Delete", "/TN", task_name, "/F"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=CREATE_NO_WINDOW,
        )
        return True
    except Exception:
        return False


def clean_hosts_line(target_line: str) -> bool:
    hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
    try:
        if os.name == "nt":
            # Сбрасываем атрибуты Read-Only / Hidden, если троян заблокировал файл hosts
            ctypes.windll.kernel32.SetFileAttributesW(hosts_path, 0x80)
        with open(hosts_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        new_lines = [ln for ln in lines if ln.strip() != target_line.strip()]
        if len(new_lines) == len(lines):
            return False
        with open(hosts_path, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        return True
    except Exception:
        return False


def kill_process_by_pid(pid: str) -> bool:
    if not str(pid).isdigit():
        return False
    _suspend_process(int(pid))
    try:
        subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=CREATE_NO_WINDOW,
        )
        return True
    except Exception:
        return False


def _is_private_ip(addr: str) -> bool:
    ip = addr.rsplit(":", 1)[0].strip("[]")
    if ip in ("127.0.0.1", "0.0.0.0", "::1", "::", "*"):
        return True
    if ip.startswith(("192.168.", "10.", "169.254.", "fe80:")):
        return True
    if ip.startswith("172."):
        parts = ip.split(".")
        if len(parts) >= 2 and parts[1].isdigit() and 16 <= int(parts[1]) <= 31:
            return True
    return False


def get_active_connections():
    conns = []
    pid_names = _get_pid_names()
    out = _run_cmd(["netstat", "-ano", "-p", "TCP"])
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 5:
            proto, local_addr, remote_addr, state, pid, *_ = p
            if proto == "TCP" and state in ("ESTABLISHED", "SYN_SENT"):
                if not _is_private_ip(remote_addr):
                    proc_name = pid_names.get(pid, "Системный процесс")
                    tag = " [Попытка связи]" if state == "SYN_SENT" else ""
                    conns.append((f"{proc_name} (PID {pid})", local_addr, f"-> {remote_addr}{tag}"))
    return conns
