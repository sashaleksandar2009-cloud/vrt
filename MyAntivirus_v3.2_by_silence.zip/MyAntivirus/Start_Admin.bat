@echo off
chcp 65001 >nul
python -c "import pefile" 2>nul || pip install pefile
powershell -Command "Start-Process python -ArgumentList 'gui_antivirus.py' -Verb RunAs"
